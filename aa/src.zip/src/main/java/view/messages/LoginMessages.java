package view.messages;

public enum LoginMessages {
    INVALID_USERNAME,
    INCORRECT_PASSWORD,
    LOGIN_SUCCESS;
}
