package view;

import javafx.scene.media.Media;
import javafx.scene.media.MediaPlayer;

import java.io.File;
import java.net.URI;
import java.util.ArrayList;

public class MusicPlayer {
    public static void play(int index) {

    }
}
